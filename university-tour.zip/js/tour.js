function changeScene(sceneName) {
  const sky = document.querySelector('#sky');
  const audio = document.querySelector('#scene-audio');

  const scenes = {
    library: {
      img: 'assets/images/library.jpg',
      audio: 'assets/audio/library.mp3'
    },
    canteen: {
      img: 'assets/images/canteen.jpg',
      audio: 'assets/audio/canteen.mp3'
    }
  };

  if (scenes[sceneName]) {
    sky.setAttribute('src', scenes[sceneName].img);
    audio.setAttribute('src', scenes[sceneName].audio);
    audio.components.sound.stopSound();
    audio.components.sound.playSound();
  }
}